import './App.css'
import BankerAlgorithm from './components/BankerAlgorithm'

function App() {
  return (
    <div className="app-container">
      <BankerAlgorithm />
    </div>
  )
}

export default App

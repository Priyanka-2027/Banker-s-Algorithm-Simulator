import { useState } from 'react'
import './BankerAlgorithm.css'

function BankerAlgorithm() {
  const [numProcesses, setNumProcesses] = useState('')
  const [numResources, setNumResources] = useState('')
  const [available, setAvailable] = useState([])
  const [allocated, setAllocated] = useState([])
  const [need, setNeed] = useState([])
  const [step, setStep] = useState(1)
  const [result, setResult] = useState(null)
  const [executionSteps, setExecutionSteps] = useState([])

  const handleSetup = () => {
    const n = parseInt(numProcesses)
    const r = parseInt(numResources)

    if (n > 0 && r > 0) {
      setAvailable(new Array(r).fill(0))
      setAllocated(Array.from({ length: n }, () => new Array(r).fill(0)))
      setNeed(Array.from({ length: n }, () => new Array(r).fill(0)))
      setStep(2)
    }
  }

  const handleAvailableChange = (index, value) => {
    const newAvailable = [...available]
    newAvailable[index] = parseInt(value) || 0
    setAvailable(newAvailable)
  }

  const handleAllocatedChange = (processIndex, resourceIndex, value) => {
    const newAllocated = [...allocated]
    newAllocated[processIndex][resourceIndex] = parseInt(value) || 0
    setAllocated(newAllocated)
  }

  const handleNeedChange = (processIndex, resourceIndex, value) => {
    const newNeed = [...need]
    newNeed[processIndex][resourceIndex] = parseInt(value) || 0
    setNeed(newNeed)
  }

  const canExecute = (needArray, availableArray) => {
    for (let i = 0; i < needArray.length; i++) {
      if (needArray[i] > availableArray[i]) {
        return false
      }
    }
    return true
  }

  const runBankerAlgorithm = () => {
    const n = parseInt(numProcesses)
    const r = parseInt(numResources)
    const availableCopy = [...available]
    const executed = new Set()
    const safeSequence = []
    const steps = []

    while (executed.size < n) {
      let found = false

      for (let i = 0; i < n; i++) {
        if (executed.has(i)) {
          continue
        }

        if (canExecute(need[i], availableCopy)) {
          safeSequence.push(i)
          executed.add(i)
          found = true

          const stepInfo = {
            process: i,
            needBefore: [...need[i]],
            availableBefore: [...availableCopy],
            allocated: [...allocated[i]]
          }

          for (let j = 0; j < r; j++) {
            availableCopy[j] += allocated[i][j]
          }

          stepInfo.availableAfter = [...availableCopy]
          steps.push(stepInfo)
        }
      }

      if (!found) {
        setResult({
          success: false,
          message: 'Safe state is not possible - Deadlock detected!'
        })
        setExecutionSteps([])
        return
      }
    }

    setResult({
      success: true,
      sequence: safeSequence,
      message: 'Safe sequence found!'
    })
    setExecutionSteps(steps)
  }

  const reset = () => {
    setNumProcesses('')
    setNumResources('')
    setAvailable([])
    setAllocated([])
    setNeed([])
    setStep(1)
    setResult(null)
    setExecutionSteps([])
  }

  return (
    <div className="banker-container">
      <h1>Banker's Algorithm - Deadlock Avoidance</h1>

      {step === 1 && (
        <div className="input-section">
          <h2>Step 1: Initial Setup</h2>
          <div className="input-group">
            <label>
              Number of Processes:
              <input
                type="number"
                min="1"
                value={numProcesses}
                onChange={(e) => setNumProcesses(e.target.value)}
              />
            </label>
          </div>
          <div className="input-group">
            <label>
              Number of Resources:
              <input
                type="number"
                min="1"
                value={numResources}
                onChange={(e) => setNumResources(e.target.value)}
              />
            </label>
          </div>
          <button onClick={handleSetup} className="btn-primary">Next</button>
        </div>
      )}

      {step === 2 && (
        <div className="input-section">
          <h2>Step 2: Enter Available Resources</h2>
          <div className="matrix-container">
            <div className="resource-inputs">
              {available.map((val, index) => (
                <div key={index} className="input-group">
                  <label>
                    Resource {index}:
                    <input
                      type="number"
                      min="0"
                      value={val}
                      onChange={(e) => handleAvailableChange(index, e.target.value)}
                    />
                  </label>
                </div>
              ))}
            </div>
          </div>
          <div className="button-group">
            <button onClick={() => setStep(1)} className="btn-secondary">Back</button>
            <button onClick={() => setStep(3)} className="btn-primary">Next</button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="input-section">
          <h2>Step 3: Enter Allocated Resources</h2>
          <div className="matrix-container">
            <table className="matrix-table">
              <thead>
                <tr>
                  <th>Process</th>
                  {Array.from({ length: parseInt(numResources) }, (_, i) => (
                    <th key={i}>R{i}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {allocated.map((row, pIndex) => (
                  <tr key={pIndex}>
                    <td>P{pIndex}</td>
                    {row.map((val, rIndex) => (
                      <td key={rIndex}>
                        <input
                          type="number"
                          min="0"
                          value={val}
                          onChange={(e) => handleAllocatedChange(pIndex, rIndex, e.target.value)}
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="button-group">
            <button onClick={() => setStep(2)} className="btn-secondary">Back</button>
            <button onClick={() => setStep(4)} className="btn-primary">Next</button>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="input-section">
          <h2>Step 4: Enter Need Resources</h2>
          <div className="matrix-container">
            <table className="matrix-table">
              <thead>
                <tr>
                  <th>Process</th>
                  {Array.from({ length: parseInt(numResources) }, (_, i) => (
                    <th key={i}>R{i}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {need.map((row, pIndex) => (
                  <tr key={pIndex}>
                    <td>P{pIndex}</td>
                    {row.map((val, rIndex) => (
                      <td key={rIndex}>
                        <input
                          type="number"
                          min="0"
                          value={val}
                          onChange={(e) => handleNeedChange(pIndex, rIndex, e.target.value)}
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="button-group">
            <button onClick={() => setStep(3)} className="btn-secondary">Back</button>
            <button onClick={runBankerAlgorithm} className="btn-success">Calculate Safe Sequence</button>
          </div>
        </div>
      )}

      {result && (
        <div className={`result-section ${result.success ? 'success' : 'error'}`}>
          <h2>Result</h2>
          <p className="result-message">{result.message}</p>

          {result.success && (
            <div className="safe-sequence">
              <h3>Safe Sequence:</h3>
              <div className="sequence-display">
                {result.sequence.map((process, index) => (
                  <span key={index}>
                    P{process}
                    {index < result.sequence.length - 1 && ' → '}
                  </span>
                ))}
              </div>
            </div>
          )}

          {executionSteps.length > 0 && (
            <div className="execution-steps">
              <h3>Execution Steps:</h3>
              {executionSteps.map((step, index) => (
                <div key={index} className="step-card">
                  <h4>Step {index + 1}: Execute Process P{step.process}</h4>
                  <div className="step-details">
                    <div className="detail-row">
                      <span className="label">Need:</span>
                      <span className="values">[{step.needBefore.join(', ')}]</span>
                    </div>
                    <div className="detail-row">
                      <span className="label">Available (Before):</span>
                      <span className="values">[{step.availableBefore.join(', ')}]</span>
                    </div>
                    <div className="detail-row">
                      <span className="label">Allocated:</span>
                      <span className="values">[{step.allocated.join(', ')}]</span>
                    </div>
                    <div className="detail-row">
                      <span className="label">Available (After):</span>
                      <span className="values highlight">[{step.availableAfter.join(', ')}]</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <button onClick={reset} className="btn-primary">Start Over</button>
        </div>
      )}
    </div>
  )
}

export default BankerAlgorithm
